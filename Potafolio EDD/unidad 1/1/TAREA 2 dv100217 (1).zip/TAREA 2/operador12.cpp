#include <iostream>
using namespace std;

int main(){

    int x = 5;
    int y = 2;
    cout << x + y << endl;
    cout << x - y << endl;
    cout << x * y << endl;

    x = 12;
    y = 3;
    cout << x / y << endl;

    x = 5;
    y = 2;
    cout << x % y << endl;

    ++x;
    cout << x << endl;

    x = 5;
    --x;
    cout << x << endl;

}
