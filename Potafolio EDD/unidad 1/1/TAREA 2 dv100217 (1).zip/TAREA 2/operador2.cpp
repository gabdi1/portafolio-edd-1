#include <iostream>
using namespace std;

int main(){

double x;
double y;

cout << "*** Calcula operaciones aritmetica de dos numeros *** \n";

cout << "Inserte numero: ";
cin >> x;

cout << "Inserte el otro numero: ";
cin >> y;

cout << "Suma: " << x + y << endl;
cout << "Resta: " << x - y << endl;
cout << "Multi: " << x * y << endl;
cout << "Div: " << x / y << endl;

int z = x;
int w = y;
cout << "El Residuo de la div " << z % w << endl;

++x;
++y;
cout << "Incremento de uno: " << "x: " << x << "y: " << y << endl;

--x;
--y;
cout << "Decremento de uno: " << "x: " << x << "y: " << y << endl;

return 0;

}
