#include <iostream>
using namespace std;

int main(){

int x;
int y;

cin >> x;
cin >> y;

x +=y;
cout << x << endl;

x -=y;
cout << x << endl;

x *=y;
cout << x << endl;

x /=y;
cout << x << endl;

x %=y;
cout << x << endl;

return 0;
}
