#include <iostream>
using namespace std;

int main(){

int x;
int y;

cin>>x;
cin>>y;

bool var1 = true;
bool var2 = false;

cout << var1 << endl;
cout << var2 << endl;

cout << (x<y) << endl;
cout << (x>y) << endl;
cout << (x<=y) << endl;
cout << (x>=y) << endl;
cout << (x!=y) << endl;
cout << (x==y) << endl;

return 0;
}
